<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class BarangApi extends CI_Controller {
	// fungsi untuk CREATE
	public function addBarang()
	{
	
		// deklarasi variable
		$nama = $this->input->post('nama');
		$nomer = $this->input->post('nomer');
		$exp = $this->input->post('exp');
		$jenis = $this->input->post('jenis');
		$hobi = $this->input->post('hobi');

	// isikan variabel dengan nama file
		$data['nama_barang'] = $nama;
		$data['nomer_barang'] = $nomer;
		$data['expired_barang'] = $exp;
		$data['jenis_kelamin'] = $jenis;
		$data['hobi_penyetor'] = $hobi;
		$q = $this->db->insert('tb_barang', $data);
	

	// check insert berhasil atau tidak
		if ($q) {
		$response['pesan'] = 'insert berhasil';
		$response['status'] = 200;
		} else {
		$response['pesan'] = 'insert error';
		$response['status'] = 404;
		}
		echo json_encode($response);
	}

	// fungsi untuk READ
		public function getDataBarang()
		{
		$q = $this->db->get('tb_barang');
		if ($q -> num_rows() > 0) {
		$response['pesan'] = 'data ada';
		$response['status'] = 200;


	// 1 row
		$response['barang'] = $q->row();
		$response['barang'] = $q->result();
		} else {
		$response['pesan'] = 'data tidak ada';
		$response['status'] = 404;
		}
		echo json_encode($response);
	}

	// fungsi untuk DELETE
		public function deleteBarang()
		{
		$id = $this->input->post('id');
		$this->db->where('barang_id', $id);
		$status = $this->db->delete('tb_barang');
		if ($status == true) {
		$response['pesan'] = 'hapus berhasil';
		$response['status'] = 200;
		} else {
		$response['pesan'] = 'hapus error';
		$response['status'] = 404;
		}
		echo json_encode($response);
	}

// fungsi untuk UPDATE
		public function updateBarang()
	{

// deklarasi variable
		$id = $this->input->post('id');
		$nama = $this->input->post('nama');
		$nomer = $this->input->post('nomer');
		$exp = $this->input->post('expired');
		$jenis = $this->input->post('jenis');
		$hobi = $this->input->post('hobi');
		$this->db->where('barang id', $id);

// isikan variabel dengan nama file
		$data['barang'] = $barang;
		$data['nomer'] = $nomer;
		$data['expired'] = $expired;
		$data['jenis'] = $jenis;
		$data['hobi'] = $hobi;
		$q = $this->db->update('tb_barang', $data);


// check insert berhasil atau tidak
		if ($q) {
		$response['pesan'] = 'update berhasil';
		$response['status'] = 200;
		} else {
		$response['pesan'] = 'update error';
		$response['status'] = 404;
		}
		echo json_encode($response);
	}
}