package com.irham.barangjual

import retrofit2.Call
import retrofit2.Response
class PresenterUpdateData (val tampilanCRUD: UpdateDataBarang) {
    //Add data
    fun addData(nama : String, nomer : String, exp : String, jenis : String, hobi : String){
        konfigurasiJaringan.getService()
            .addBarang( nama, nomer, exp, jenis, hobi)
            .enqueue(object : retrofit2.Callback<ResultStatusBarang>{
                override fun onFailure(call: Call<ResultStatusBarang>, t: Throwable) {
                    tampilanCRUD.errorAdd(t.localizedMessage)
                }
                override fun onResponse(call: Call<ResultStatusBarang>, response: Response<ResultStatusBarang>) {
                    if (response.isSuccessful && response.body()?.status == 200) {
                        tampilanCRUD.successAdd(response.body()?.pesan ?: "")
                    }else {
                        tampilanCRUD.errorAdd(response.body()?.pesan ?: "")
                    }
                }
            })
    }
    //Update Data
    fun updateData(id: String, nama: String, nomer: String, exp: String, jenis: String, hobi: String){
        konfigurasiJaringan.getService()
            .updateBarang(id, nama, nomer, exp, jenis, hobi)
            .enqueue(object : retrofit2.Callback<ResultStatusBarang>{
                override fun onFailure(call: Call<ResultStatusBarang>, t: Throwable) {
                    tampilanCRUD.onErrorUpdate(t.localizedMessage)
                }
                override fun onResponse(call: Call<ResultStatusBarang>, response: Response<ResultStatusBarang>) {
                    if (response.isSuccessful && response.body()?.status == 200){
                        tampilanCRUD.onSuccessUpdate(response.body()?.pesan ?: "")
                    }else{
                        tampilanCRUD.onErrorUpdate(response.body()?.pesan ?: "")
                    }
                }
            })
    }
}