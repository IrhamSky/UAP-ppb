package com.irham.barangjual

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView
import kotlinx.android.synthetic.main.layout_itemdata.view.*

class DataAdapter(val data: List<RagamData>? , private val click: onClickItem) : RecyclerView.Adapter<DataAdapter.MyHolder>() {
    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): MyHolder {
        val view = LayoutInflater.from(parent.context).inflate(R.layout.layout_itemdata,parent,false)
        return MyHolder(view)
    }
    override fun getItemCount() = data?.size ?: 0
    override fun onBindViewHolder(holder: MyHolder, position: Int) {
        holder.onBind(data?.get(position))
        holder.itemView.setOnClickListener() {
            click.clicked(data?.get(position))
        }
        holder.itemView.btnDelete.setOnClickListener {
            click.delete(data?.get(position))
        }
    }
    class MyHolder(itemView: View) : RecyclerView.ViewHolder(itemView) {
        fun onBind(get: RagamData?) {
            itemView.tvid.text = get?.barangID
            itemView.tvnama.text = get?.namaBarang
            itemView.tvnomer.text = get?.nomerBarang
            itemView.tvexpired.text = get?.expiredBarang
            itemView.tvjenis.text = get?.jenisKelamin
            itemView.tvhobi.text = get?.hobiPenyetor
        }
    }
    interface onClickItem{
        fun clicked (item: RagamData?)
        fun delete(item: RagamData?)
    }
}