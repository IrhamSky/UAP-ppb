package com.irham.barangjual

import okhttp3.OkHttpClient
import okhttp3.logging.HttpLoggingInterceptor
import retrofit2.Call
import retrofit2.Retrofit
import retrofit2.converter.gson.GsonConverterFactory
import retrofit2.http.Field
import retrofit2.http.FormUrlEncoded
import retrofit2.http.GET
import retrofit2.http.POST
object konfigurasiJaringan {
    fun getInterceptor() : OkHttpClient {
        val logging = HttpLoggingInterceptor()
        logging.level = HttpLoggingInterceptor.Level.BODY
        val okHttpClient = OkHttpClient.Builder()
            .addInterceptor(logging)
            .build()
        return okHttpClient
    }
    //Retrofit (obyek yang dapat dipanggil)
    fun getRetrofit(): Retrofit {
        return Retrofit.Builder()
            .baseUrl("http://10.0.2.2/barang_api/index.php/BarangApi/")
            .client(getInterceptor())
            .addConverterFactory(GsonConverterFactory.create())
            .build()
    }
    fun getService() = getRetrofit().create(BarangService::class.java)
}
interface BarangService{
    //Fungsi Create Data
    @FormUrlEncoded
    @POST("addBarang")
    fun addBarang(@Field("nama") nama : String,
                @Field("nomer") nomer : String,
                 @Field("exp") exp : String,
                 @Field("jenis") jenis : String,
                  @Field("hobi") hobi : String) : Call<ResultStatusBarang>
    //Fungsi Get Data
    @GET("getDataBarang")
    fun getData() : Call<ResultBarang>
    //Fungsi Delete Data
    @FormUrlEncoded
    @POST("deleteBarang")
    fun deleteBarang(@Field("id") id: String?) : Call<ResultStatusBarang>
    //Fungsi Update Data
    @FormUrlEncoded
    @POST("updateBarang")
    fun updateBarang(@Field("id") id: String,
                     @Field("nama") nama: String,
                     @Field("nomer") nomer: String,
                     @Field("exp") exp: String,
                     @Field("jenis") jenis: String,
                     @Field("hobi") hobi: String) : Call<ResultStatusBarang>
}