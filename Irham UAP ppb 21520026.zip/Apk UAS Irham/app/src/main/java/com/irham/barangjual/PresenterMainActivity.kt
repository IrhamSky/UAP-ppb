package com.irham.barangjual

import android.util.Log
import retrofit2.Call
import retrofit2.Response
import java.sql.ResultSet

class PresenterMainActivity(val tampilanCRUD: MainActivity) {
    //Fungsi GetData
    fun getData(){
        konfigurasiJaringan.getService().getData()
            .enqueue(object : retrofit2.Callback<ResultBarang>{
                override fun onFailure(call: Call<ResultBarang>, t: Throwable) {
                    tampilanCRUD.onFailedGet(t.localizedMessage)
                    Log.d("Error", "Error Data")
                }
                override fun onResponse(call: Call<ResultBarang>, response: Response<ResultBarang>) {
                    if(response.isSuccessful){
                        val status = response.body()?.status
                        if (status == 200){
                            val data = response.body()?.barang
                            tampilanCRUD.onSuccessGet(data)
                        } else{
                            tampilanCRUD.onFailedGet("Error $status")
                        }
                    }
                }
            })
    }
    //Hapus Data
    fun hapusData(id: String?){
        konfigurasiJaringan.getService()
            .deleteBarang(id)
            .enqueue(object : retrofit2.Callback<ResultStatusBarang>{
                override fun onFailure(call: Call<ResultStatusBarang>, t: Throwable) {
                    tampilanCRUD.onErrorDelete(t.localizedMessage)
                }
                override fun onResponse(call: Call<ResultStatusBarang>, response: Response<ResultStatusBarang>) {
                    if (response.isSuccessful && response.body()?.status == 200){
                        tampilanCRUD.onSuccessDelete(response.body()?.pesan ?: "")
                    } else {
                        tampilanCRUD.onErrorDelete(response.body()?.pesan ?: "")
                    }
                }
            })
    }
}