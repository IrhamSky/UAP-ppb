package com.irham.barangjual

class ResultStatusBarang {
    val pesan : String? = null
    val status : Int? = null
}