package com.irham.barangjual

import com.google.gson.annotations.SerializedName
data class ResultBarang (
    @field:SerializedName("pesan")
    val pesan: String? = null,
    @field:SerializedName("barang")
    val barang: List<RagamData>? = null,
    @field:SerializedName("status")
    val status: Int? = null
)