package com.irham.barangjual

import com.google.gson.annotations.SerializedName
import java.io.Serializable
class RagamData : Serializable{
    @field:SerializedName("barang_id")
    val barangID: String? = null
    @field:SerializedName("nama_barang")
    val namaBarang: String? = null
    @field:SerializedName("nomer_barang")
    val nomerBarang: String? = null
    @field:SerializedName("expired_barang")
    val expiredBarang: String? = null
    @field:SerializedName("jenis_kelamin")
    val jenisKelamin: String? = null
    @field:SerializedName("hobi_penyetor")
    val hobiPenyetor: String? = null
}