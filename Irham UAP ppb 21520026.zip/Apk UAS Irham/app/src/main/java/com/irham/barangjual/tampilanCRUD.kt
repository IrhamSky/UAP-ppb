package com.irham.barangjual

interface tampilanCRUD {
    //Untuk get data
    fun onSuccessGet(data: List<RagamData>?)
    fun onFailedGet(msg : String)
    //Untuk menghapus data
    fun onSuccessDelete(msg: String)
    fun onErrorDelete(msg: String)
    //Untuk menambah data
    fun successAdd(msg : String)
    fun errorAdd(msg: String)
    //Untuk memperbarui data
    fun onSuccessUpdate(msg : String)
    fun onErrorUpdate(msg : String)
}